# Swarm Architecture Diagram

![Swarm Architecture Diagram](https://raw.githubusercontent.com/ethersphere/swarm-guide/master/contents/img/high-level-components.svg?sanitize=true "Swarm Architecture Diagram")

This diagram represents a high-level description of the most important components in Swarm.

For more information refer to the [Swarm Documentation](https://swarm-guide.readthedocs.io) and to the [Architecture](https://swarm-guide.readthedocs.io/en/latest/architecture.html) chapter.
