// Copyright 2018 The go-ethereum Authors
// This file is part of go-ethereum.
//
// go-ethereum is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// go-ethereum is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with go-ethereum. If not, see <http://www.gnu.org/licenses/>.

// Command feed allows the user to create and update signed Swarm feeds
package main

import (
	"github.com/ethersphere/swarm/network"
	cli "gopkg.in/urfave/cli.v1"
)

var (
	SwarmAccountFlag = cli.StringFlag{
		Name:   "bzzaccount",
		Usage:  "Swarm account key file",
		EnvVar: SwarmEnvAccount,
	}
	SwarmBzzKeyHexFlag = cli.StringFlag{
		Name:   "bzzkeyhex",
		Usage:  "BzzAccount key in hex (for testing)",
		EnvVar: SwarmEnvBzzKeyHex,
	}
	SwarmListenAddrFlag = cli.StringFlag{
		Name:   "httpaddr",
		Usage:  "Swarm HTTP API listening interface",
		EnvVar: SwarmEnvListenAddr,
	}
	SwarmPortFlag = cli.StringFlag{
		Name:   "bzzport",
		Usage:  "Swarm local http api port",
		EnvVar: SwarmEnvPort,
	}
	SwarmNATInterfaceFlag = cli.StringFlag{
		Name:   "natif",
		Usage:  "Announce the IP address of a given network interface (e.g. eth0)",
		EnvVar: SwarmEnvNATInterface,
	}
	SwarmNetworkIdFlag = cli.IntFlag{
		Name:   "bzznetworkid",
		Usage:  "Numerical network identifier. The default is the public swarm testnet",
		Value:  network.DefaultNetworkID,
		EnvVar: SwarmEnvNetworkID,
	}
	SwarmSwapDepositAmountFlag = cli.StringFlag{
		Name:   "swap-deposit-amount",
		Usage:  "Deposit amount for swap chequebook",
		EnvVar: SwarmEnvSwapDepositAmount,
	}
	SwarmSwapSkipDepositFlag = cli.BoolFlag{
		Name:   "swap-skip-deposit",
		Usage:  "Don't deposit during boot sequence",
		EnvVar: SwarmEnvSwapSkipDeposit,
	}
	SwarmSwapChequebookAddrFlag = cli.StringFlag{
		Name:   "swap-chequebook",
		Usage:  "SWAP chequebook contract address",
		EnvVar: SwarmEnvChequebookAddr,
	}
	SwarmSwapChequebookFactoryFlag = cli.StringFlag{
		Name:   "swap-chequebook-factory",
		Usage:  "SWAP chequebook factory contract address",
		EnvVar: SwarmEnvChequebookFactoryAddr,
	}
	SwarmSwapEnabledFlag = cli.BoolFlag{
		Name:   "swap",
		Usage:  "Swarm SWAP enabled (default false)",
		EnvVar: SwarmEnvSwapEnable,
	}
	SwarmSwapBackendURLFlag = cli.StringFlag{
		Name:   "swap-backend-url",
		Usage:  "URL of the Ethereum API provider to use to settle SWAP payments",
		EnvVar: SwarmEnvSwapBackendURL,
	}
	SwarmSwapPaymentThresholdFlag = cli.Uint64Flag{
		Name:   "swap-payment-threshold",
		Usage:  "honey amount at which payment is triggered",
		EnvVar: SwarmEnvSwapPaymentThreshold,
	}
	SwarmSwapDisconnectThresholdFlag = cli.Uint64Flag{
		Name:   "swap-disconnect-threshold",
		Usage:  "honey amount at which a peer disconnects",
		EnvVar: SwarmEnvSwapDisconnectThreshold,
	}
	SwarmNoSyncFlag = cli.BoolFlag{
		Name:   "no-sync",
		Usage:  "disable syncing",
		EnvVar: SwarmNoSync,
	}
	SwarmSwapLogPathFlag = cli.StringFlag{
		Name:   "swap-audit-logpath",
		Usage:  "Write execution logs of swap audit to the given directory",
		EnvVar: SwarmEnvSwapLogPath,
	}
	SwarmSwapLogLevelFlag = cli.StringFlag{
		Name:   "swap-audit-loglevel",
		Usage:  "Default log level of swap audit logs",
		EnvVar: SwarmEnvSwapLogLevel,
	}
	SwarmLightNodeEnabled = cli.BoolFlag{
		Name:   "lightnode",
		Usage:  "Enable Swarm LightNode (default false)",
		EnvVar: SwarmEnvLightNodeEnable,
	}
	EnsAPIFlag = cli.StringSliceFlag{
		Name:   "ens-api",
		Usage:  "ENS API endpoint for a TLD and with contract address, can be repeated, format [tld:][contract-addr@]url",
		EnvVar: SwarmEnvENSAPI,
	}
	RnsAPIFlag = cli.StringFlag{
		Name:   "rns-api",
		Usage:  "RNS API endpoint for RKS domains contract address, format [contract-addr@]url",
		EnvVar: SwarmEnvRNSAPI,
	}
	SwarmApiFlag = cli.StringFlag{
		Name:  "bzzapi",
		Usage: "Specifies the Swarm HTTP endpoint to connect to",
		Value: "http://127.0.0.1:8500",
	}
	SwarmRecursiveFlag = cli.BoolFlag{
		Name:  "recursive",
		Usage: "Upload directories recursively",
	}
	SwarmWantManifestFlag = cli.BoolTFlag{
		Name:  "manifest",
		Usage: "Automatic manifest upload (default true)",
	}
	SwarmUploadDefaultPath = cli.StringFlag{
		Name:  "defaultpath",
		Usage: "path to file served for empty url path (none)",
	}
	SwarmAccessGrantKeyFlag = cli.StringFlag{
		Name:  "grant-key",
		Usage: "grants a given public key access to an ACT",
	}
	SwarmAccessGrantKeysFlag = cli.StringFlag{
		Name:  "grant-keys",
		Usage: "grants a given list of public keys in the following file (separated by line breaks) access to an ACT",
	}
	SwarmUpFromStdinFlag = cli.BoolFlag{
		Name:  "stdin",
		Usage: "reads data to be uploaded from stdin",
	}
	SwarmUploadMimeType = cli.StringFlag{
		Name:  "mime",
		Usage: "Manually specify MIME type",
	}
	SwarmEncryptedFlag = cli.BoolFlag{
		Name:  "encrypt",
		Usage: "use encrypted upload",
	}
	SwarmAccessPasswordFlag = cli.StringFlag{
		Name:   "password",
		Usage:  "Password",
		EnvVar: SwarmAccessPassword,
	}
	SwarmDryRunFlag = cli.BoolFlag{
		Name:  "dry-run",
		Usage: "dry-run",
	}
	CorsStringFlag = cli.StringFlag{
		Name:   "corsdomain",
		Usage:  "Domain on which to send Access-Control-Allow-Origin header (multiple domains can be supplied separated by a ',')",
		EnvVar: SwarmEnvCORS,
	}
	SwarmStorePath = cli.StringFlag{
		Name:   "store.path",
		Usage:  "Path to leveldb chunk DB (default <$GETH_ENV_DIR>/swarm/bzz-<$BZZ_KEY>/chunks)",
		EnvVar: SwarmEnvStorePath,
	}
	SwarmStoreCapacity = cli.Uint64Flag{
		Name:   "store.size",
		Usage:  "Number of chunks (5M is roughly 20-25GB) (default 5000000)",
		EnvVar: SwarmEnvStoreCapacity,
	}
	SwarmStoreCacheCapacity = cli.UintFlag{
		Name:   "store.cache.size",
		Usage:  "Number of recent chunks cached in memory",
		EnvVar: SwarmEnvStoreCacheCapacity,
		Value:  10000,
	}
	SwarmCompressedFlag = cli.BoolFlag{
		Name:  "compressed",
		Usage: "Prints encryption keys in compressed form",
	}
	SwarmBootnodeModeFlag = cli.BoolFlag{
		Name:  "bootnode-mode",
		Usage: "Run Swarm in Bootnode mode",
	}
	SwarmDisableAutoConnectFlag = cli.BoolFlag{
		Name:  "disable-auto-connect",
		Usage: "Disables the peer discovery mechanism in the hive protocol as well as the auto connect loop (manual peer addition)",
	}
	SwarmFeedNameFlag = cli.StringFlag{
		Name:  "name",
		Usage: "User-defined name for the new feed, limited to 32 characters. If combined with topic, it will refer to a subtopic with this name",
	}
	SwarmFeedTopicFlag = cli.StringFlag{
		Name:  "topic",
		Usage: "User-defined topic this feed is tracking, hex encoded. Limited to 64 hexadecimal characters",
	}
	SwarmFeedManifestFlag = cli.StringFlag{
		Name:  "manifest",
		Usage: "Refers to the feed through a manifest",
	}
	SwarmFeedUserFlag = cli.StringFlag{
		Name:  "user",
		Usage: "Indicates the user who updates the feed",
	}
	SwarmGlobalStoreAPIFlag = cli.StringFlag{
		Name:   "globalstore-api",
		Usage:  "URL of the Global Store API provider (only for testing)",
		EnvVar: SwarmGlobalstoreAPI,
	}
	SwarmLegacyFlag = cli.BoolFlag{
		Name:  "legacy",
		Usage: "Use this flag when importing a db export from a legacy local store database dump (for schemas older than 'sanctuary')",
	}
	SwarmPinFlag = cli.BoolFlag{
		Name:  "pin",
		Usage: "Use this flag to pin the file after upload is complete. This flag is used when uploading a file.",
	}
	SwarmEnablePinningFlag = cli.BoolFlag{
		Name:  "enable-pinning",
		Usage: "Use this flag to enable the pinning feature",
	}
	SwarmProgressFlag = cli.BoolFlag{
		Name:  "progress",
		Usage: "Use this flag to enable tracking of the upload progress through the CLI",
	}
	SwarmAnonymousUploadFlag = cli.BoolFlag{
		Name:  "anonymous",
		Usage: "use this flag to upload anonymously",
	}
	SwarmVerboseFlag = cli.BoolFlag{
		Name:  "verbose",
		Usage: "Display more verbose output",
	}
	SwarmMutexProfileFlag = cli.BoolFlag{
		Name:  "mutex-profile",
		Usage: "Enable pprof mutex profile",
	}
	SwarmBlockProfileFlag = cli.BoolFlag{
		Name:  "block-profile",
		Usage: "Enable pprof block profile",
	}
)
